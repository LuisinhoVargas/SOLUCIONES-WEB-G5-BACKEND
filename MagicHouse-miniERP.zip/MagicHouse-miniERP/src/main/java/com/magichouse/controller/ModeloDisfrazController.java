package com.magichouse.controller;

import com.magichouse.dto.ModeloDisfrazDTO;
import com.magichouse.model.ModeloDisfraz;
import com.magichouse.service.interfaces.IModeloDisfrazService;
import lombok.RequiredArgsConstructor;
import org.modelmapper.ModelMapper;
import org.springframework.hateoas.EntityModel;
import org.springframework.hateoas.server.mvc.WebMvcLinkBuilder;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.servlet.support.ServletUriComponentsBuilder;

import java.net.URI;
import java.util.List;

@RestController
@RequiredArgsConstructor
@RequestMapping("/modelos-disfraz")
public class ModeloDisfrazController {

    private final IModeloDisfrazService service;
    private final ModelMapper modelMapper;

    @GetMapping
    public ResponseEntity<List<ModeloDisfrazDTO>> findAll() throws Exception {
        List<ModeloDisfrazDTO> list = service.findAll().stream().map(e -> modelMapper.map(e, ModeloDisfrazDTO.class)).toList();
        return ResponseEntity.ok(list);
    }

    @GetMapping("/{id}")
    public ResponseEntity<ModeloDisfrazDTO> findById(@PathVariable Integer id) throws Exception {
        ModeloDisfraz obj = service.findById(id);
        return ResponseEntity.ok(modelMapper.map(obj, ModeloDisfrazDTO.class));
    }

    @PostMapping
    public ResponseEntity<Void> save(@RequestBody ModeloDisfrazDTO dto) throws Exception {
        ModeloDisfraz obj = service.save(modelMapper.map(dto, ModeloDisfraz.class));
        URI location = ServletUriComponentsBuilder.fromCurrentRequest().path("/{id}").buildAndExpand(obj.getIdModeloDisfraz()).toUri();
        return ResponseEntity.created(location).build();
    }

    @PutMapping("/{id}")
    public ResponseEntity<ModeloDisfrazDTO> update(@PathVariable Integer id, @RequestBody ModeloDisfrazDTO dto) throws Exception {
        ModeloDisfraz obj = service.update(modelMapper.map(dto, ModeloDisfraz.class), id);
        return ResponseEntity.ok(modelMapper.map(obj, ModeloDisfrazDTO.class));
    }

    @DeleteMapping("/{id}")
    public ResponseEntity<Void> delete(@PathVariable Integer id) throws Exception {
        service.delete(id);
        return ResponseEntity.noContent().build();
    }

    @GetMapping("/hateoas/{id}")
    public EntityModel<ModeloDisfrazDTO> findByIdHateoas(@PathVariable Integer id) throws Exception{
        ModeloDisfraz obj = service.findById(id);
        EntityModel<ModeloDisfrazDTO> entityModel = EntityModel.of(modelMapper.map(obj, ModeloDisfrazDTO.class));
        WebMvcLinkBuilder link1 = WebMvcLinkBuilder.linkTo(WebMvcLinkBuilder.methodOn(ModeloDisfrazController.class).findById(id));
        WebMvcLinkBuilder link2 = WebMvcLinkBuilder.linkTo(WebMvcLinkBuilder.methodOn(ModeloDisfrazController.class).findAll());
        entityModel.add(link1.withRel("modelo-disfraz-self-info"));
        entityModel.add(link2.withRel("modelo-disfraz-all-info"));
        return entityModel;
    }
}