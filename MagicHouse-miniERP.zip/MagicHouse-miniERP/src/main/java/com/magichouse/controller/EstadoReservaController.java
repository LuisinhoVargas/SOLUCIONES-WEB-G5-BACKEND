package com.magichouse.controller;

import com.magichouse.dto.EstadoReservaDTO;
import com.magichouse.model.EstadoReserva;
import com.magichouse.service.interfaces.IEstadoReservaService;
import lombok.RequiredArgsConstructor;
import org.modelmapper.ModelMapper;
import org.springframework.hateoas.EntityModel;
import org.springframework.hateoas.server.mvc.WebMvcLinkBuilder;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.servlet.support.ServletUriComponentsBuilder;

import java.net.URI;
import java.util.List;

@RestController
@RequiredArgsConstructor
@RequestMapping("/estados-reserva")
public class EstadoReservaController {

    private final IEstadoReservaService service;
    private final ModelMapper modelMapper;

    @GetMapping
    public ResponseEntity<List<EstadoReservaDTO>> findAll() throws Exception {
        List<EstadoReservaDTO> list = service.findAll().stream().map(e -> modelMapper.map(e, EstadoReservaDTO.class)).toList();
        return ResponseEntity.ok(list);
    }

    @GetMapping("/{id}")
    public ResponseEntity<EstadoReservaDTO> findById(@PathVariable Short id) throws Exception {
        EstadoReserva obj = service.findById(id);
        return ResponseEntity.ok(modelMapper.map(obj, EstadoReservaDTO.class));
    }

    @PostMapping
    public ResponseEntity<Void> save(@RequestBody EstadoReservaDTO dto) throws Exception {
        EstadoReserva obj = service.save(modelMapper.map(dto, EstadoReserva.class));
        URI location = ServletUriComponentsBuilder.fromCurrentRequest().path("/{id}").buildAndExpand(obj.getIdEstadoReserva()).toUri();
        return ResponseEntity.created(location).build();
    }

    @PutMapping("/{id}")
    public ResponseEntity<EstadoReservaDTO> update(@PathVariable Short id, @RequestBody EstadoReservaDTO dto) throws Exception {
        EstadoReserva obj = service.update(modelMapper.map(dto, EstadoReserva.class), id);
        return ResponseEntity.ok(modelMapper.map(obj, EstadoReservaDTO.class));
    }

    @DeleteMapping("/{id}")
    public ResponseEntity<Void> delete(@PathVariable Short id) throws Exception {
        service.delete(id);
        return ResponseEntity.noContent().build();
    }

    @GetMapping("/hateoas/{id}")
    public EntityModel<EstadoReservaDTO> findByIdHateoas(@PathVariable Short id) throws Exception{
        EstadoReserva obj = service.findById(id);
        EntityModel<EstadoReservaDTO> entityModel = EntityModel.of(modelMapper.map(obj, EstadoReservaDTO.class));
        WebMvcLinkBuilder link1 = WebMvcLinkBuilder.linkTo(WebMvcLinkBuilder.methodOn(EstadoReservaController.class).findById(id));
        WebMvcLinkBuilder link2 = WebMvcLinkBuilder.linkTo(WebMvcLinkBuilder.methodOn(EstadoReservaController.class).findAll());
        entityModel.add(link1.withRel("estado-reserva-self-info"));
        entityModel.add(link2.withRel("estado-reserva-all-info"));
        return entityModel;
    }
}