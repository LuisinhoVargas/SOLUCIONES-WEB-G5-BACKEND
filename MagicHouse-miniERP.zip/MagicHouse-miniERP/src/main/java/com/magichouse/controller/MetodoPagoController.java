package com.magichouse.controller;

import com.magichouse.dto.MetodoPagoDTO;
import com.magichouse.model.MetodoPago;
import com.magichouse.service.interfaces.IMetodoPagoService;
import lombok.RequiredArgsConstructor;
import org.modelmapper.ModelMapper;
import org.springframework.hateoas.EntityModel;
import org.springframework.hateoas.server.mvc.WebMvcLinkBuilder;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.servlet.support.ServletUriComponentsBuilder;

import java.net.URI;
import java.util.List;

@RestController
@RequiredArgsConstructor
@RequestMapping("/metodos-pago")
public class MetodoPagoController {

    private final IMetodoPagoService service;
    private final ModelMapper modelMapper;

    @GetMapping
    public ResponseEntity<List<MetodoPagoDTO>> findAll() throws Exception {
        List<MetodoPagoDTO> list = service.findAll().stream().map(e -> modelMapper.map(e, MetodoPagoDTO.class)).toList();
        return ResponseEntity.ok(list);
    }

    @GetMapping("/{id}")
    public ResponseEntity<MetodoPagoDTO> findById(@PathVariable Short id) throws Exception {
        MetodoPago obj = service.findById(id);
        return ResponseEntity.ok(modelMapper.map(obj, MetodoPagoDTO.class));
    }

    @PostMapping
    public ResponseEntity<Void> save(@RequestBody MetodoPagoDTO dto) throws Exception {
        MetodoPago obj = service.save(modelMapper.map(dto, MetodoPago.class));
        URI location = ServletUriComponentsBuilder.fromCurrentRequest().path("/{id}").buildAndExpand(obj.getIdMetodoPago()).toUri();
        return ResponseEntity.created(location).build();
    }

    @PutMapping("/{id}")
    public ResponseEntity<MetodoPagoDTO> update(@PathVariable Short id, @RequestBody MetodoPagoDTO dto) throws Exception {
        MetodoPago obj = service.update(modelMapper.map(dto, MetodoPago.class), id);
        return ResponseEntity.ok(modelMapper.map(obj, MetodoPagoDTO.class));
    }

    @DeleteMapping("/{id}")
    public ResponseEntity<Void> delete(@PathVariable Short id) throws Exception {
        service.delete(id);
        return ResponseEntity.noContent().build();
    }

    @GetMapping("/hateoas/{id}")
    public EntityModel<MetodoPagoDTO> findByIdHateoas(@PathVariable Short id) throws Exception{
        MetodoPago obj = service.findById(id);
        EntityModel<MetodoPagoDTO> entityModel = EntityModel.of(modelMapper.map(obj, MetodoPagoDTO.class));
        WebMvcLinkBuilder link1 = WebMvcLinkBuilder.linkTo(WebMvcLinkBuilder.methodOn(MetodoPagoController.class).findById(id));
        WebMvcLinkBuilder link2 = WebMvcLinkBuilder.linkTo(WebMvcLinkBuilder.methodOn(MetodoPagoController.class).findAll());
        entityModel.add(link1.withRel("metodo-pago-self-info"));
        entityModel.add(link2.withRel("metodo-pago-all-info"));
        return entityModel;
    }
}