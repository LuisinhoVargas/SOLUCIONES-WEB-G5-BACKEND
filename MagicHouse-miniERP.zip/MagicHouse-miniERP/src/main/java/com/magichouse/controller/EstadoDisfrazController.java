package com.magichouse.controller;

import com.magichouse.dto.EstadoDisfrazDTO;
import com.magichouse.model.EstadoDisfraz;
import com.magichouse.service.interfaces.IEstadoDisfrazService;
import lombok.RequiredArgsConstructor;
import org.modelmapper.ModelMapper;
import org.springframework.hateoas.EntityModel;
import org.springframework.hateoas.server.mvc.WebMvcLinkBuilder;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.servlet.support.ServletUriComponentsBuilder;

import java.net.URI;
import java.util.List;

@RestController
@RequiredArgsConstructor
@RequestMapping("/estados-disfraz")
public class EstadoDisfrazController {

    private final IEstadoDisfrazService service;
    private final ModelMapper modelMapper;

    @GetMapping
    public ResponseEntity<List<EstadoDisfrazDTO>> findAll() throws Exception {
        List<EstadoDisfrazDTO> list = service.findAll().stream().map(e -> modelMapper.map(e, EstadoDisfrazDTO.class)).toList();
        return ResponseEntity.ok(list);
    }

    @GetMapping("/{id}")
    public ResponseEntity<EstadoDisfrazDTO> findById(@PathVariable Short id) throws Exception {
        EstadoDisfraz obj = service.findById(id);
        return ResponseEntity.ok(modelMapper.map(obj, EstadoDisfrazDTO.class));
    }

    @PostMapping
    public ResponseEntity<Void> save(@RequestBody EstadoDisfrazDTO dto) throws Exception {
        EstadoDisfraz obj = service.save(modelMapper.map(dto, EstadoDisfraz.class));
        URI location = ServletUriComponentsBuilder.fromCurrentRequest().path("/{id}").buildAndExpand(obj.getIdEstadoDisfraz()).toUri();
        return ResponseEntity.created(location).build();
    }

    @PutMapping("/{id}")
    public ResponseEntity<EstadoDisfrazDTO> update(@PathVariable Short id, @RequestBody EstadoDisfrazDTO dto) throws Exception {
        EstadoDisfraz obj = service.update(modelMapper.map(dto, EstadoDisfraz.class), id);
        return ResponseEntity.ok(modelMapper.map(obj, EstadoDisfrazDTO.class));
    }

    @DeleteMapping("/{id}")
    public ResponseEntity<Void> delete(@PathVariable Short id) throws Exception {
        service.delete(id);
        return ResponseEntity.noContent().build();
    }

    @GetMapping("/hateoas/{id}")
    public EntityModel<EstadoDisfrazDTO> findByIdHateoas(@PathVariable Short id) throws Exception{
        EstadoDisfraz obj = service.findById(id);
        EntityModel<EstadoDisfrazDTO> entityModel = EntityModel.of(modelMapper.map(obj, EstadoDisfrazDTO.class));
        WebMvcLinkBuilder link1 = WebMvcLinkBuilder.linkTo(WebMvcLinkBuilder.methodOn(EstadoDisfrazController.class).findById(id));
        WebMvcLinkBuilder link2 = WebMvcLinkBuilder.linkTo(WebMvcLinkBuilder.methodOn(EstadoDisfrazController.class).findAll());
        entityModel.add(link1.withRel("estado-disfraz-self-info"));
        entityModel.add(link2.withRel("estado-disfraz-all-info"));
        return entityModel;
    }
}