package com.magichouse.controller;

import com.magichouse.dto.VentaDTO;
import com.magichouse.model.Venta;
import com.magichouse.service.interfaces.IVentaService;
import lombok.RequiredArgsConstructor;
import org.modelmapper.ModelMapper;
import org.springframework.hateoas.EntityModel;
import org.springframework.hateoas.server.mvc.WebMvcLinkBuilder;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.servlet.support.ServletUriComponentsBuilder;

import java.net.URI;
import java.util.List;

@RestController
@RequiredArgsConstructor
@RequestMapping("/ventas")
public class VentaController {

    private final IVentaService service;
    private final ModelMapper modelMapper;

    @GetMapping
    public ResponseEntity<List<VentaDTO>> findAll() throws Exception {
        List<VentaDTO> list = service.findAll().stream().map(e -> modelMapper.map(e, VentaDTO.class)).toList();
        return ResponseEntity.ok(list);
    }

    @GetMapping("/{id}")
    public ResponseEntity<VentaDTO> findById(@PathVariable Integer id) throws Exception {
        Venta obj = service.findById(id);
        return ResponseEntity.ok(modelMapper.map(obj, VentaDTO.class));
    }

    @PostMapping
    public ResponseEntity<Void> save(@RequestBody VentaDTO dto) throws Exception {
        Venta obj = service.save(modelMapper.map(dto, Venta.class));
        URI location = ServletUriComponentsBuilder.fromCurrentRequest().path("/{id}").buildAndExpand(obj.getIdVenta()).toUri();
        return ResponseEntity.created(location).build();
    }

    @PutMapping("/{id}")
    public ResponseEntity<VentaDTO> update(@PathVariable Integer id, @RequestBody VentaDTO dto) throws Exception {
        Venta obj = service.update(modelMapper.map(dto, Venta.class), id);
        return ResponseEntity.ok(modelMapper.map(obj, VentaDTO.class));
    }

    @DeleteMapping("/{id}")
    public ResponseEntity<Void> delete(@PathVariable Integer id) throws Exception {
        service.delete(id);
        return ResponseEntity.noContent().build();
    }

    @GetMapping("/hateoas/{id}")
    public EntityModel<VentaDTO> findByIdHateoas(@PathVariable Integer id) throws Exception{
        Venta obj = service.findById(id);
        EntityModel<VentaDTO> entityModel = EntityModel.of(modelMapper.map(obj, VentaDTO.class));
        WebMvcLinkBuilder link1 = WebMvcLinkBuilder.linkTo(WebMvcLinkBuilder.methodOn(VentaController.class).findById(id));
        WebMvcLinkBuilder link2 = WebMvcLinkBuilder.linkTo(WebMvcLinkBuilder.methodOn(VentaController.class).findAll());
        entityModel.add(link1.withRel("venta-self-info"));
        entityModel.add(link2.withRel("venta-all-info"));
        return entityModel;
    }
}