package com.magichouse.controller;

import com.magichouse.dto.ItemDisfrazDTO;
import com.magichouse.model.ItemDisfraz;
import com.magichouse.service.interfaces.IItemDisfrazService;
import lombok.RequiredArgsConstructor;
import org.modelmapper.ModelMapper;
import org.springframework.hateoas.EntityModel;
import org.springframework.hateoas.server.mvc.WebMvcLinkBuilder;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.servlet.support.ServletUriComponentsBuilder;

import java.net.URI;
import java.util.List;

@RestController
@RequiredArgsConstructor
@RequestMapping("/items-disfraz")
public class ItemDisfrazController {

    private final IItemDisfrazService service;
    private final ModelMapper modelMapper;

    @GetMapping
    public ResponseEntity<List<ItemDisfrazDTO>> findAll() throws Exception {
        List<ItemDisfrazDTO> list = service.findAll().stream().map(e -> modelMapper.map(e, ItemDisfrazDTO.class)).toList();
        return ResponseEntity.ok(list);
    }

    @GetMapping("/{id}")
    public ResponseEntity<ItemDisfrazDTO> findById(@PathVariable Integer id) throws Exception {
        ItemDisfraz obj = service.findById(id);
        return ResponseEntity.ok(modelMapper.map(obj, ItemDisfrazDTO.class));
    }

    @PostMapping
    public ResponseEntity<Void> save(@RequestBody ItemDisfrazDTO dto) throws Exception {
        ItemDisfraz obj = service.save(modelMapper.map(dto, ItemDisfraz.class));
        URI location = ServletUriComponentsBuilder.fromCurrentRequest().path("/{id}").buildAndExpand(obj.getIdItemDisfraz()).toUri();
        return ResponseEntity.created(location).build();
    }

    @PutMapping("/{id}")
    public ResponseEntity<ItemDisfrazDTO> update(@PathVariable Integer id, @RequestBody ItemDisfrazDTO dto) throws Exception {
        ItemDisfraz obj = service.update(modelMapper.map(dto, ItemDisfraz.class), id);
        return ResponseEntity.ok(modelMapper.map(obj, ItemDisfrazDTO.class));
    }

    @DeleteMapping("/{id}")
    public ResponseEntity<Void> delete(@PathVariable Integer id) throws Exception {
        service.delete(id);
        return ResponseEntity.noContent().build();
    }

    @GetMapping("/hateoas/{id}")
    public EntityModel<ItemDisfrazDTO> findByIdHateoas(@PathVariable Integer id) throws Exception{
        ItemDisfraz obj = service.findById(id);
        EntityModel<ItemDisfrazDTO> entityModel = EntityModel.of(modelMapper.map(obj, ItemDisfrazDTO.class));
        WebMvcLinkBuilder link1 = WebMvcLinkBuilder.linkTo(WebMvcLinkBuilder.methodOn(ItemDisfrazController.class).findById(id));
        WebMvcLinkBuilder link2 = WebMvcLinkBuilder.linkTo(WebMvcLinkBuilder.methodOn(ItemDisfrazController.class).findAll());
        entityModel.add(link1.withRel("item-disfraz-self-info"));
        entityModel.add(link2.withRel("item-disfraz-all-info"));
        return entityModel;
    }
}