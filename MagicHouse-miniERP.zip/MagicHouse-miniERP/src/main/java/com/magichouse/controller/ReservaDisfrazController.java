package com.magichouse.controller;

import com.magichouse.dto.ReservaDisfrazDTO;
import com.magichouse.model.ReservaDisfraz;
import com.magichouse.service.interfaces.IReservaDisfrazService;
import lombok.RequiredArgsConstructor;
import org.modelmapper.ModelMapper;
import org.springframework.hateoas.EntityModel;
import org.springframework.hateoas.server.mvc.WebMvcLinkBuilder;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.servlet.support.ServletUriComponentsBuilder;

import java.net.URI;
import java.util.List;

@RestController
@RequiredArgsConstructor
@RequestMapping("/reservas")
public class ReservaDisfrazController {

    private final IReservaDisfrazService service;
    private final ModelMapper modelMapper;

    @GetMapping
    public ResponseEntity<List<ReservaDisfrazDTO>> findAll() throws Exception {
        List<ReservaDisfrazDTO> list = service.findAll().stream().map(e -> modelMapper.map(e, ReservaDisfrazDTO.class)).toList();
        return ResponseEntity.ok(list);
    }

    @GetMapping("/{id}")
    public ResponseEntity<ReservaDisfrazDTO> findById(@PathVariable Long id) throws Exception {
        ReservaDisfraz obj = service.findById(id);
        return ResponseEntity.ok(modelMapper.map(obj, ReservaDisfrazDTO.class));
    }

    @PostMapping
    public ResponseEntity<Void> save(@RequestBody ReservaDisfrazDTO dto) throws Exception {
        ReservaDisfraz obj = service.save(modelMapper.map(dto, ReservaDisfraz.class));
        URI location = ServletUriComponentsBuilder.fromCurrentRequest().path("/{id}").buildAndExpand(obj.getIdReserva()).toUri();
        return ResponseEntity.created(location).build();
    }

    @PutMapping("/{id}")
    public ResponseEntity<ReservaDisfrazDTO> update(@PathVariable Long id, @RequestBody ReservaDisfrazDTO dto) throws Exception {
        ReservaDisfraz obj = service.update(modelMapper.map(dto, ReservaDisfraz.class), id);
        return ResponseEntity.ok(modelMapper.map(obj, ReservaDisfrazDTO.class));
    }

    @DeleteMapping("/{id}")
    public ResponseEntity<Void> delete(@PathVariable Long id) throws Exception {
        service.delete(id);
        return ResponseEntity.noContent().build();
    }

    @GetMapping("/hateoas/{id}")
    public EntityModel<ReservaDisfrazDTO> findByIdHateoas(@PathVariable Long id) throws Exception{
        ReservaDisfraz obj = service.findById(id);
        EntityModel<ReservaDisfrazDTO> entityModel = EntityModel.of(modelMapper.map(obj, ReservaDisfrazDTO.class));
        WebMvcLinkBuilder link1 = WebMvcLinkBuilder.linkTo(WebMvcLinkBuilder.methodOn(ReservaDisfrazController.class).findById(id));
        WebMvcLinkBuilder link2 = WebMvcLinkBuilder.linkTo(WebMvcLinkBuilder.methodOn(ReservaDisfrazController.class).findAll());
        entityModel.add(link1.withRel("reserva-disfraz-self-info"));
        entityModel.add(link2.withRel("reserva-disfraz-all-info"));
        return entityModel;
    }
}