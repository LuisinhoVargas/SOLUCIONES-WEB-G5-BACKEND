package com.magichouse.controller;

import com.magichouse.dto.TallaDTO;
import com.magichouse.model.Talla;
import com.magichouse.service.interfaces.ITallaService;
import lombok.RequiredArgsConstructor;
import org.modelmapper.ModelMapper;
import org.springframework.hateoas.EntityModel;
import org.springframework.hateoas.server.mvc.WebMvcLinkBuilder;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.servlet.support.ServletUriComponentsBuilder;

import java.net.URI;
import java.util.List;

@RestController
@RequiredArgsConstructor
@RequestMapping("/tallas")
public class TallaController {

    private final ITallaService service;
    private final ModelMapper modelMapper;

    @GetMapping
    public ResponseEntity<List<TallaDTO>> findAll() throws Exception {
        List<TallaDTO> list = service.findAll().stream().map(e -> modelMapper.map(e, TallaDTO.class)).toList();
        return ResponseEntity.ok(list);
    }

    @GetMapping("/{id}")
    public ResponseEntity<TallaDTO> findById(@PathVariable Short id) throws Exception {
        Talla obj = service.findById(id);
        return ResponseEntity.ok(modelMapper.map(obj, TallaDTO.class));
    }

    @PostMapping
    public ResponseEntity<Void> save(@RequestBody TallaDTO dto) throws Exception {
        Talla obj = service.save(modelMapper.map(dto, Talla.class));
        URI location = ServletUriComponentsBuilder.fromCurrentRequest().path("/{id}").buildAndExpand(obj.getIdTalla()).toUri();
        return ResponseEntity.created(location).build();
    }

    @PutMapping("/{id}")
    public ResponseEntity<TallaDTO> update(@PathVariable Short id, @RequestBody TallaDTO dto) throws Exception {
        Talla obj = service.update(modelMapper.map(dto, Talla.class), id);
        return ResponseEntity.ok(modelMapper.map(obj, TallaDTO.class));
    }

    @DeleteMapping("/{id}")
    public ResponseEntity<Void> delete(@PathVariable Short id) throws Exception {
        service.delete(id);
        return ResponseEntity.noContent().build();
    }

    @GetMapping("/hateoas/{id}")
    public EntityModel<TallaDTO> findByIdHateoas(@PathVariable Short id) throws Exception{
        Talla obj = service.findById(id);
        EntityModel<TallaDTO> entityModel = EntityModel.of(modelMapper.map(obj, TallaDTO.class));
        WebMvcLinkBuilder link1 = WebMvcLinkBuilder.linkTo(WebMvcLinkBuilder.methodOn(TallaController.class).findById(id));
        WebMvcLinkBuilder link2 = WebMvcLinkBuilder.linkTo(WebMvcLinkBuilder.methodOn(TallaController.class).findAll());
        entityModel.add(link1.withRel("talla-self-info"));
        entityModel.add(link2.withRel("talla-all-info"));
        return entityModel;
    }
}