package com.magichouse.controller;

import com.magichouse.dto.UsuarioDTO;
import com.magichouse.model.Usuario;
import com.magichouse.service.interfaces.IUsuarioService;
import lombok.RequiredArgsConstructor;
import org.modelmapper.ModelMapper;
import org.springframework.hateoas.EntityModel;
import org.springframework.hateoas.server.mvc.WebMvcLinkBuilder;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.servlet.support.ServletUriComponentsBuilder;

import java.net.URI;
import java.util.List;

@RestController
@RequiredArgsConstructor
@RequestMapping("/usuarios")
public class UsuarioController {

    private final IUsuarioService service;
    private final ModelMapper modelMapper;

    @GetMapping
    public ResponseEntity<List<UsuarioDTO>> findAll() throws Exception {
        List<UsuarioDTO> list = service.findAll().stream().map(e -> modelMapper.map(e, UsuarioDTO.class)).toList();
        return ResponseEntity.ok(list);
    }

    @GetMapping("/{id}")
    public ResponseEntity<UsuarioDTO> findById(@PathVariable Short id) throws Exception {
        Usuario obj = service.findById(id);
        return ResponseEntity.ok(modelMapper.map(obj, UsuarioDTO.class));
    }

    @PostMapping
    public ResponseEntity<Void> save(@RequestBody UsuarioDTO dto) throws Exception {
        Usuario obj = service.save(modelMapper.map(dto, Usuario.class));
        URI location = ServletUriComponentsBuilder.fromCurrentRequest().path("/{id}").buildAndExpand(obj.getIdUsuario()).toUri();
        return ResponseEntity.created(location).build();
    }

    @PutMapping("/{id}")
    public ResponseEntity<UsuarioDTO> update(@PathVariable Short id, @RequestBody UsuarioDTO dto) throws Exception {
        Usuario obj = service.update(modelMapper.map(dto, Usuario.class), id);
        return ResponseEntity.ok(modelMapper.map(obj, UsuarioDTO.class));
    }

    @DeleteMapping("/{id}")
    public ResponseEntity<Void> delete(@PathVariable Short id) throws Exception {
        service.delete(id);
        return ResponseEntity.noContent().build();
    }

    @GetMapping("/hateoas/{id}")
    public EntityModel<UsuarioDTO> findByIdHateoas(@PathVariable Short id) throws Exception{
        Usuario obj = service.findById(id);
        EntityModel<UsuarioDTO> entityModel = EntityModel.of(modelMapper.map(obj, UsuarioDTO.class));
        WebMvcLinkBuilder link1 = WebMvcLinkBuilder.linkTo(WebMvcLinkBuilder.methodOn(UsuarioController.class).findById(id));
        WebMvcLinkBuilder link2 = WebMvcLinkBuilder.linkTo(WebMvcLinkBuilder.methodOn(UsuarioController.class).findAll());
        entityModel.add(link1.withRel("usuario-self-info"));
        entityModel.add(link2.withRel("usuario-all-info"));
        return entityModel;
    }
}