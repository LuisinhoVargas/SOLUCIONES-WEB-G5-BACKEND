package com.magichouse.controller;

import com.magichouse.dto.ClienteDTO;
import com.magichouse.model.Cliente;
import com.magichouse.service.interfaces.IClienteService;
import lombok.RequiredArgsConstructor;
import org.modelmapper.ModelMapper;
import org.springframework.hateoas.EntityModel;
import org.springframework.hateoas.server.mvc.WebMvcLinkBuilder;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.servlet.support.ServletUriComponentsBuilder;

import java.net.URI;
import java.util.List;

@RestController
@RequiredArgsConstructor
@RequestMapping("/clientes")
public class ClienteController {

    private final IClienteService service;
    private final ModelMapper modelMapper;

    @GetMapping
    public ResponseEntity<List<ClienteDTO>> findAll() throws Exception {
        List<ClienteDTO> list = service.findAll().stream().map(e -> modelMapper.map(e, ClienteDTO.class)).toList();
        return ResponseEntity.ok(list);
    }

    @GetMapping("/{id}")
    public ResponseEntity<ClienteDTO> findById(@PathVariable Integer id) throws Exception {
        Cliente obj = service.findById(id);
        return ResponseEntity.ok(modelMapper.map(obj, ClienteDTO.class));
    }

    @PostMapping
    public ResponseEntity<Void> save(@RequestBody ClienteDTO dto) throws Exception {
        Cliente obj = service.save(modelMapper.map(dto, Cliente.class));
        URI location = ServletUriComponentsBuilder.fromCurrentRequest().path("/{id}").buildAndExpand(obj.getIdCliente()).toUri();
        return ResponseEntity.created(location).build();
    }

    @PutMapping("/{id}")
    public ResponseEntity<ClienteDTO> update(@PathVariable Integer id, @RequestBody ClienteDTO dto) throws Exception {
        Cliente obj = service.update(modelMapper.map(dto, Cliente.class), id);
        return ResponseEntity.ok(modelMapper.map(obj, ClienteDTO.class));
    }

    @DeleteMapping("/{id}")
    public ResponseEntity<Void> delete(@PathVariable Integer id) throws Exception {
        service.delete(id);
        return ResponseEntity.noContent().build();
    }

    @GetMapping("/hateoas/{id}")
    public EntityModel<ClienteDTO> findByIdHateoas(@PathVariable Integer id) throws Exception{
        Cliente obj = service.findById(id);
        EntityModel<ClienteDTO> entityModel = EntityModel.of(modelMapper.map(obj, ClienteDTO.class));
        WebMvcLinkBuilder link1 = WebMvcLinkBuilder.linkTo(WebMvcLinkBuilder.methodOn(ClienteController.class).findById(id));
        WebMvcLinkBuilder link2 = WebMvcLinkBuilder.linkTo(WebMvcLinkBuilder.methodOn(ClienteController.class).findAll());
        entityModel.add(link1.withRel("cliente-self-info"));
        entityModel.add(link2.withRel("cliente-all-info"));
        return entityModel;
    }
}