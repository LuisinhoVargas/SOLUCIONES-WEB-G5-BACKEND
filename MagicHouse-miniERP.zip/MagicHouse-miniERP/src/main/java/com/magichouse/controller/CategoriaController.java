package com.magichouse.controller;

import com.magichouse.dto.CategoriaDTO;
import com.magichouse.model.Categoria;
import com.magichouse.service.interfaces.ICategoriaService;
import lombok.RequiredArgsConstructor;
import org.modelmapper.ModelMapper;
import org.springframework.hateoas.EntityModel;
import org.springframework.hateoas.server.mvc.WebMvcLinkBuilder;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.servlet.support.ServletUriComponentsBuilder;

import java.net.URI;
import java.util.List;

@RestController
@RequiredArgsConstructor
@RequestMapping("/categorias")
public class CategoriaController {

    private final ICategoriaService service;
    private final ModelMapper modelMapper;

    @GetMapping
    public ResponseEntity<List<CategoriaDTO>> findAll() throws Exception {
        List<CategoriaDTO> list = service.findAll().stream().map(e -> modelMapper.map(e, CategoriaDTO.class)).toList();
        return ResponseEntity.ok(list);
    }

    @GetMapping("/{id}")
    public ResponseEntity<CategoriaDTO> findById(@PathVariable Short id) throws Exception {
        Categoria obj = service.findById(id);
        return ResponseEntity.ok(modelMapper.map(obj, CategoriaDTO.class));
    }

    @PostMapping
    public ResponseEntity<Void> save(@RequestBody CategoriaDTO dto) throws Exception {
        Categoria obj = service.save(modelMapper.map(dto, Categoria.class));
        URI location = ServletUriComponentsBuilder.fromCurrentRequest().path("/{id}").buildAndExpand(obj.getIdCategoria()).toUri();
        return ResponseEntity.created(location).build();
    }

    @PutMapping("/{id}")
    public ResponseEntity<CategoriaDTO> update(@PathVariable Short id, @RequestBody CategoriaDTO dto) throws Exception {
        Categoria obj = service.update(modelMapper.map(dto, Categoria.class), id);
        return ResponseEntity.ok(modelMapper.map(obj, CategoriaDTO.class));
    }

    @DeleteMapping("/{id}")
    public ResponseEntity<Void> delete(@PathVariable Short id) throws Exception {
        service.delete(id);
        return ResponseEntity.noContent().build();
    }

    @GetMapping("/hateoas/{id}")
    public EntityModel<CategoriaDTO> findByIdHateoas(@PathVariable Short id) throws Exception{
        Categoria obj = service.findById(id);
        EntityModel<CategoriaDTO> entityModel = EntityModel.of(modelMapper.map(obj, CategoriaDTO.class));
        WebMvcLinkBuilder link1 = WebMvcLinkBuilder.linkTo(WebMvcLinkBuilder.methodOn(CategoriaController.class).findById(id));
        WebMvcLinkBuilder link2 = WebMvcLinkBuilder.linkTo(WebMvcLinkBuilder.methodOn(CategoriaController.class).findAll());
        entityModel.add(link1.withRel("categoria-self-info"));
        entityModel.add(link2.withRel("categoria-all-info"));
        return entityModel;
    }
}