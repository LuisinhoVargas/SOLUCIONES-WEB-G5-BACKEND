package com.magichouse.controller;

import com.magichouse.dto.TipoMovimientoDTO;
import com.magichouse.model.TipoMovimiento;
import com.magichouse.service.interfaces.ITipoMovimientoService;
import lombok.RequiredArgsConstructor;
import org.modelmapper.ModelMapper;
import org.springframework.hateoas.EntityModel;
import org.springframework.hateoas.server.mvc.WebMvcLinkBuilder;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.servlet.support.ServletUriComponentsBuilder;

import java.net.URI;
import java.util.List;

@RestController
@RequiredArgsConstructor
@RequestMapping("/tipos-movimiento")
public class TipoMovimientoController {

    private final ITipoMovimientoService service;
    private final ModelMapper modelMapper;

    @GetMapping
    public ResponseEntity<List<TipoMovimientoDTO>> findAll() throws Exception {
        List<TipoMovimientoDTO> list = service.findAll().stream().map(e -> modelMapper.map(e, TipoMovimientoDTO.class)).toList();
        return ResponseEntity.ok(list);
    }

    @GetMapping("/{id}")
    public ResponseEntity<TipoMovimientoDTO> findById(@PathVariable Short id) throws Exception {
        TipoMovimiento obj = service.findById(id);
        return ResponseEntity.ok(modelMapper.map(obj, TipoMovimientoDTO.class));
    }

    @PostMapping
    public ResponseEntity<Void> save(@RequestBody TipoMovimientoDTO dto) throws Exception {
        TipoMovimiento obj = service.save(modelMapper.map(dto, TipoMovimiento.class));
        URI location = ServletUriComponentsBuilder.fromCurrentRequest().path("/{id}").buildAndExpand(obj.getIdTipoMovimiento()).toUri();
        return ResponseEntity.created(location).build();
    }

    @PutMapping("/{id}")
    public ResponseEntity<TipoMovimientoDTO> update(@PathVariable Short id, @RequestBody TipoMovimientoDTO dto) throws Exception {
        TipoMovimiento obj = service.update(modelMapper.map(dto, TipoMovimiento.class), id);
        return ResponseEntity.ok(modelMapper.map(obj, TipoMovimientoDTO.class));
    }

    @DeleteMapping("/{id}")
    public ResponseEntity<Void> delete(@PathVariable Short id) throws Exception {
        service.delete(id);
        return ResponseEntity.noContent().build();
    }

    @GetMapping("/hateoas/{id}")
    public EntityModel<TipoMovimientoDTO> findByIdHateoas(@PathVariable Short id) throws Exception{
        TipoMovimiento obj = service.findById(id);
        EntityModel<TipoMovimientoDTO> entityModel = EntityModel.of(modelMapper.map(obj, TipoMovimientoDTO.class));
        WebMvcLinkBuilder link1 = WebMvcLinkBuilder.linkTo(WebMvcLinkBuilder.methodOn(TipoMovimientoController.class).findById(id));
        WebMvcLinkBuilder link2 = WebMvcLinkBuilder.linkTo(WebMvcLinkBuilder.methodOn(TipoMovimientoController.class).findAll());
        entityModel.add(link1.withRel("tipo-movimiento-self-info"));
        entityModel.add(link2.withRel("tipo-movimiento-all-info"));
        return entityModel;
    }
}