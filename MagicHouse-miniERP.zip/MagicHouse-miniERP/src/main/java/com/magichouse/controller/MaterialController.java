package com.magichouse.controller;

import com.magichouse.dto.MaterialDTO;
import com.magichouse.model.Material;
import com.magichouse.service.interfaces.IMaterialService;
import lombok.RequiredArgsConstructor;
import org.modelmapper.ModelMapper;
import org.springframework.hateoas.EntityModel;
import org.springframework.hateoas.server.mvc.WebMvcLinkBuilder;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.servlet.support.ServletUriComponentsBuilder;

import java.net.URI;
import java.util.List;

@RestController
@RequiredArgsConstructor
@RequestMapping("/materiales")
public class MaterialController {

    private final IMaterialService service;
    private final ModelMapper modelMapper;

    @GetMapping
    public ResponseEntity<List<MaterialDTO>> findAll() throws Exception {
        List<MaterialDTO> list = service.findAll().stream().map(e -> modelMapper.map(e, MaterialDTO.class)).toList();
        return ResponseEntity.ok(list);
    }

    @GetMapping("/{id}")
    public ResponseEntity<MaterialDTO> findById(@PathVariable Short id) throws Exception {
        Material obj = service.findById(id);
        return ResponseEntity.ok(modelMapper.map(obj, MaterialDTO.class));
    }

    @PostMapping
    public ResponseEntity<Void> save(@RequestBody MaterialDTO dto) throws Exception {
        Material obj = service.save(modelMapper.map(dto, Material.class));
        URI location = ServletUriComponentsBuilder.fromCurrentRequest().path("/{id}").buildAndExpand(obj.getIdMaterial()).toUri();
        return ResponseEntity.created(location).build();
    }

    @PutMapping("/{id}")
    public ResponseEntity<MaterialDTO> update(@PathVariable Short id, @RequestBody MaterialDTO dto) throws Exception {
        Material obj = service.update(modelMapper.map(dto, Material.class), id);
        return ResponseEntity.ok(modelMapper.map(obj, MaterialDTO.class));
    }

    @DeleteMapping("/{id}")
    public ResponseEntity<Void> delete(@PathVariable Short id) throws Exception {
        service.delete(id);
        return ResponseEntity.noContent().build();
    }

    @GetMapping("/hateoas/{id}")
    public EntityModel<MaterialDTO> findByIdHateoas(@PathVariable Short id) throws Exception{
        Material obj = service.findById(id);
        EntityModel<MaterialDTO> entityModel = EntityModel.of(modelMapper.map(obj, MaterialDTO.class));
        WebMvcLinkBuilder link1 = WebMvcLinkBuilder.linkTo(WebMvcLinkBuilder.methodOn(MaterialController.class).findById(id));
        WebMvcLinkBuilder link2 = WebMvcLinkBuilder.linkTo(WebMvcLinkBuilder.methodOn(MaterialController.class).findAll());
        entityModel.add(link1.withRel("material-self-info"));
        entityModel.add(link2.withRel("material-all-info"));
        return entityModel;
    }
}