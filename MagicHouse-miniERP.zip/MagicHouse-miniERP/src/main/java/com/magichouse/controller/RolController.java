package com.magichouse.controller;

import com.magichouse.dto.RolDTO;
import com.magichouse.model.Rol;
import com.magichouse.service.interfaces.IRolService;
import lombok.RequiredArgsConstructor;
import org.modelmapper.ModelMapper;
import org.springframework.hateoas.EntityModel;
import org.springframework.hateoas.server.mvc.WebMvcLinkBuilder;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.servlet.support.ServletUriComponentsBuilder;

import java.net.URI;
import java.util.List;

@RestController
@RequiredArgsConstructor
@RequestMapping("/roles")
public class RolController {

    private final IRolService service;
    private final ModelMapper modelMapper;

    @GetMapping
    public ResponseEntity<List<RolDTO>> findAll() throws Exception {
        List<RolDTO> list = service.findAll().stream().map(e -> modelMapper.map(e, RolDTO.class)).toList();
        return ResponseEntity.ok(list);
    }

    @GetMapping("/{id}")
    public ResponseEntity<RolDTO> findById(@PathVariable Short id) throws Exception {
        Rol obj = service.findById(id);
        return ResponseEntity.ok(modelMapper.map(obj, RolDTO.class));
    }

    @PostMapping
    public ResponseEntity<Void> save(@RequestBody RolDTO dto) throws Exception {
        Rol obj = service.save(modelMapper.map(dto, Rol.class));
        URI location = ServletUriComponentsBuilder.fromCurrentRequest().path("/{id}").buildAndExpand(obj.getIdRol()).toUri();
        return ResponseEntity.created(location).build();
    }

    @PutMapping("/{id}")
    public ResponseEntity<RolDTO> update(@PathVariable Short id, @RequestBody RolDTO dto) throws Exception {
        Rol obj = service.update(modelMapper.map(dto, Rol.class), id);
        return ResponseEntity.ok(modelMapper.map(obj, RolDTO.class));
    }

    @DeleteMapping("/{id}")
    public ResponseEntity<Void> delete(@PathVariable Short id) throws Exception {
        service.delete(id);
        return ResponseEntity.noContent().build();
    }

    @GetMapping("/hateoas/{id}")
    public EntityModel<RolDTO> findByIdHateoas(@PathVariable Short id) throws Exception{
        Rol obj = service.findById(id);
        EntityModel<RolDTO> entityModel = EntityModel.of(modelMapper.map(obj, RolDTO.class));
        WebMvcLinkBuilder link1 = WebMvcLinkBuilder.linkTo(WebMvcLinkBuilder.methodOn(RolController.class).findById(id));
        WebMvcLinkBuilder link2 = WebMvcLinkBuilder.linkTo(WebMvcLinkBuilder.methodOn(RolController.class).findAll());
        entityModel.add(link1.withRel("rol-self-info"));
        entityModel.add(link2.withRel("rol-all-info"));
        return entityModel;
    }
}