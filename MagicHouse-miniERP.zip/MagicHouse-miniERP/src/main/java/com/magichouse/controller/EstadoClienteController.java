package com.magichouse.controller;

import com.magichouse.dto.EstadoClienteDTO;
import com.magichouse.model.EstadoCliente;
import com.magichouse.service.interfaces.IEstadoClienteService;
import lombok.RequiredArgsConstructor;
import org.modelmapper.ModelMapper;
import org.springframework.hateoas.EntityModel;
import org.springframework.hateoas.server.mvc.WebMvcLinkBuilder;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.servlet.support.ServletUriComponentsBuilder;

import java.net.URI;
import java.util.List;

@RestController
@RequiredArgsConstructor
@RequestMapping("/estados-cliente")
public class EstadoClienteController {

    private final IEstadoClienteService service;
    private final ModelMapper modelMapper;

    @GetMapping
    public ResponseEntity<List<EstadoClienteDTO>> findAll() throws Exception {
        List<EstadoClienteDTO> list = service.findAll().stream().map(e -> modelMapper.map(e, EstadoClienteDTO.class)).toList();
        return ResponseEntity.ok(list);
    }

    @GetMapping("/{id}")
    public ResponseEntity<EstadoClienteDTO> findById(@PathVariable Short id) throws Exception {
        EstadoCliente obj = service.findById(id);
        return ResponseEntity.ok(modelMapper.map(obj, EstadoClienteDTO.class));
    }

    @PostMapping
    public ResponseEntity<Void> save(@RequestBody EstadoClienteDTO dto) throws Exception {
        EstadoCliente obj = service.save(modelMapper.map(dto, EstadoCliente.class));
        URI location = ServletUriComponentsBuilder.fromCurrentRequest().path("/{id}").buildAndExpand(obj.getIdEstadoCliente()).toUri();
        return ResponseEntity.created(location).build();
    }

    @PutMapping("/{id}")
    public ResponseEntity<EstadoClienteDTO> update(@PathVariable Short id, @RequestBody EstadoClienteDTO dto) throws Exception {
        EstadoCliente obj = service.update(modelMapper.map(dto, EstadoCliente.class), id);
        return ResponseEntity.ok(modelMapper.map(obj, EstadoClienteDTO.class));
    }

    @DeleteMapping("/{id}")
    public ResponseEntity<Void> delete(@PathVariable Short id) throws Exception {
        service.delete(id);
        return ResponseEntity.noContent().build();
    }

    @GetMapping("/hateoas/{id}")
    public EntityModel<EstadoClienteDTO> findByIdHateoas(@PathVariable Short id) throws Exception{
        EstadoCliente obj = service.findById(id);
        EntityModel<EstadoClienteDTO> entityModel = EntityModel.of(modelMapper.map(obj, EstadoClienteDTO.class));
        WebMvcLinkBuilder link1 = WebMvcLinkBuilder.linkTo(WebMvcLinkBuilder.methodOn(EstadoClienteController.class).findById(id));
        WebMvcLinkBuilder link2 = WebMvcLinkBuilder.linkTo(WebMvcLinkBuilder.methodOn(EstadoClienteController.class).findAll());
        entityModel.add(link1.withRel("estado-cliente-self-info"));
        entityModel.add(link2.withRel("estado-cliente-all-info"));
        return entityModel;
    }
}