package com.magichouse.controller;

import com.magichouse.dto.BoletaVentaDTO;
import com.magichouse.model.BoletaVenta;
import com.magichouse.service.interfaces.IBoletaVentaService;
import lombok.RequiredArgsConstructor;
import org.modelmapper.ModelMapper;
import org.springframework.hateoas.EntityModel;
import org.springframework.hateoas.server.mvc.WebMvcLinkBuilder;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.servlet.support.ServletUriComponentsBuilder;

import java.net.URI;
import java.util.List;

@RestController
@RequiredArgsConstructor
@RequestMapping("/boletas-venta")
public class BoletaVentaController {

    private final IBoletaVentaService service;
    private final ModelMapper modelMapper;

    @GetMapping
    public ResponseEntity<List<BoletaVentaDTO>> findAll() throws Exception {
        List<BoletaVentaDTO> list = service.findAll().stream().map(e -> modelMapper.map(e, BoletaVentaDTO.class)).toList();
        return ResponseEntity.ok(list);
    }

    @GetMapping("/{id}")
    public ResponseEntity<BoletaVentaDTO> findById(@PathVariable Long id) throws Exception {
        BoletaVenta obj = service.findById(id);
        return ResponseEntity.ok(modelMapper.map(obj, BoletaVentaDTO.class));
    }

    @PostMapping
    public ResponseEntity<Void> save(@RequestBody BoletaVentaDTO dto) throws Exception {
        BoletaVenta obj = service.save(modelMapper.map(dto, BoletaVenta.class));
        URI location = ServletUriComponentsBuilder.fromCurrentRequest().path("/{id}").buildAndExpand(obj.getIdBoletaVenta()).toUri();
        return ResponseEntity.created(location).build();
    }

    @PutMapping("/{id}")
    public ResponseEntity<BoletaVentaDTO> update(@PathVariable Long id, @RequestBody BoletaVentaDTO dto) throws Exception {
        BoletaVenta obj = service.update(modelMapper.map(dto, BoletaVenta.class), id);
        return ResponseEntity.ok(modelMapper.map(obj, BoletaVentaDTO.class));
    }

    @DeleteMapping("/{id}")
    public ResponseEntity<Void> delete(@PathVariable Long id) throws Exception {
        service.delete(id);
        return ResponseEntity.noContent().build();
    }

    @GetMapping("/hateoas/{id}")
    public EntityModel<BoletaVentaDTO> findByIdHateoas(@PathVariable Long id) throws Exception{
        BoletaVenta obj = service.findById(id);
        EntityModel<BoletaVentaDTO> entityModel = EntityModel.of(modelMapper.map(obj, BoletaVentaDTO.class));
        WebMvcLinkBuilder link1 = WebMvcLinkBuilder.linkTo(WebMvcLinkBuilder.methodOn(BoletaVentaController.class).findById(id));
        WebMvcLinkBuilder link2 = WebMvcLinkBuilder.linkTo(WebMvcLinkBuilder.methodOn(BoletaVentaController.class).findAll());
        entityModel.add(link1.withRel("boleta-venta-self-info"));
        entityModel.add(link2.withRel("boleta-venta-all-info"));
        return entityModel;
    }
}