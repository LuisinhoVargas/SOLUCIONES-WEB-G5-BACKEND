package com.magichouse.controller;

import com.magichouse.dto.KardexDTO;
import com.magichouse.model.Kardex;
import com.magichouse.service.interfaces.IKardexService;
import lombok.RequiredArgsConstructor;
import org.modelmapper.ModelMapper;
import org.springframework.hateoas.EntityModel;
import org.springframework.hateoas.server.mvc.WebMvcLinkBuilder;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.servlet.support.ServletUriComponentsBuilder;

import java.net.URI;
import java.util.List;

@RestController
@RequiredArgsConstructor
@RequestMapping("/kardex")
public class KardexController {

    private final IKardexService service;
    private final ModelMapper modelMapper;

    @GetMapping
    public ResponseEntity<List<KardexDTO>> findAll() throws Exception {
        List<KardexDTO> list = service.findAll().stream().map(e -> modelMapper.map(e, KardexDTO.class)).toList();
        return ResponseEntity.ok(list);
    }

    @GetMapping("/{id}")
    public ResponseEntity<KardexDTO> findById(@PathVariable Long id) throws Exception {
        Kardex obj = service.findById(id);
        return ResponseEntity.ok(modelMapper.map(obj, KardexDTO.class));
    }

    @PostMapping
    public ResponseEntity<Void> save(@RequestBody KardexDTO dto) throws Exception {
        Kardex obj = service.save(modelMapper.map(dto, Kardex.class));
        URI location = ServletUriComponentsBuilder.fromCurrentRequest().path("/{id}").buildAndExpand(obj.getIdKardex()).toUri();
        return ResponseEntity.created(location).build();
    }

    @PutMapping("/{id}")
    public ResponseEntity<KardexDTO> update(@PathVariable Long id, @RequestBody KardexDTO dto) throws Exception {
        Kardex obj = service.update(modelMapper.map(dto, Kardex.class), id);
        return ResponseEntity.ok(modelMapper.map(obj, KardexDTO.class));
    }

    @DeleteMapping("/{id}")
    public ResponseEntity<Void> delete(@PathVariable Long id) throws Exception {
        service.delete(id);
        return ResponseEntity.noContent().build();
    }

    @GetMapping("/hateoas/{id}")
    public EntityModel<KardexDTO> findByIdHateoas(@PathVariable Long id) throws Exception{
        Kardex obj = service.findById(id);
        EntityModel<KardexDTO> entityModel = EntityModel.of(modelMapper.map(obj, KardexDTO.class));
        WebMvcLinkBuilder link1 = WebMvcLinkBuilder.linkTo(WebMvcLinkBuilder.methodOn(KardexController.class).findById(id));
        WebMvcLinkBuilder link2 = WebMvcLinkBuilder.linkTo(WebMvcLinkBuilder.methodOn(KardexController.class).findAll());
        entityModel.add(link1.withRel("kardex-self-info"));
        entityModel.add(link2.withRel("kardex-all-info"));
        return entityModel;
    }
}