package com.magichouse.controller;

import com.magichouse.dto.AlquilerDTO;
import com.magichouse.model.Alquiler;
import com.magichouse.service.interfaces.IAlquilerService;
import lombok.RequiredArgsConstructor;
import org.modelmapper.ModelMapper;
import org.springframework.hateoas.EntityModel;
import org.springframework.hateoas.server.mvc.WebMvcLinkBuilder;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.servlet.support.ServletUriComponentsBuilder;

import java.net.URI;
import java.util.List;

@RestController
@RequiredArgsConstructor
@RequestMapping("/alquileres")
public class AlquilerController {

    private final IAlquilerService service;
    private final ModelMapper modelMapper;

    @GetMapping
    public ResponseEntity<List<AlquilerDTO>> findAll() throws Exception {
        List<AlquilerDTO> list = service.findAll().stream().map(e -> modelMapper.map(e, AlquilerDTO.class)).toList();
        return ResponseEntity.ok(list);
    }

    @GetMapping("/{id}")
    public ResponseEntity<AlquilerDTO> findById(@PathVariable Long id) throws Exception {
        Alquiler obj = service.findById(id);
        return ResponseEntity.ok(modelMapper.map(obj, AlquilerDTO.class));
    }

    @PostMapping
    public ResponseEntity<Void> save(@RequestBody AlquilerDTO dto) throws Exception {
        Alquiler obj = service.save(modelMapper.map(dto, Alquiler.class));
        URI location = ServletUriComponentsBuilder.fromCurrentRequest().path("/{id}").buildAndExpand(obj.getIdAlquiler()).toUri();
        return ResponseEntity.created(location).build();
    }

    @PutMapping("/{id}")
    public ResponseEntity<AlquilerDTO> update(@PathVariable Long id, @RequestBody AlquilerDTO dto) throws Exception {
        Alquiler obj = service.update(modelMapper.map(dto, Alquiler.class), id);
        return ResponseEntity.ok(modelMapper.map(obj, AlquilerDTO.class));
    }

    @DeleteMapping("/{id}")
    public ResponseEntity<Void> delete(@PathVariable Long id) throws Exception {
        service.delete(id);
        return ResponseEntity.noContent().build();
    }

    @GetMapping("/hateoas/{id}")
    public EntityModel<AlquilerDTO> findByIdHateoas(@PathVariable Long id) throws Exception{
        Alquiler obj = service.findById(id);
        EntityModel<AlquilerDTO> entityModel = EntityModel.of(modelMapper.map(obj, AlquilerDTO.class));
        WebMvcLinkBuilder link1 = WebMvcLinkBuilder.linkTo(WebMvcLinkBuilder.methodOn(AlquilerController.class).findById(id));
        WebMvcLinkBuilder link2 = WebMvcLinkBuilder.linkTo(WebMvcLinkBuilder.methodOn(AlquilerController.class).findAll());
        entityModel.add(link1.withRel("alquiler-self-info"));
        entityModel.add(link2.withRel("alquiler-all-info"));
        return entityModel;
    }
}