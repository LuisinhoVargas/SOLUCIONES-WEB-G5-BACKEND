package com.magichouse.service.implementation;

import org.springframework.stereotype.Service;

import com.magichouse.model.Categoria;
import com.magichouse.repository.ICategoriaRepository;
import com.magichouse.repository.IGenericoRepository;

import lombok.RequiredArgsConstructor;

@Service
@RequiredArgsConstructor
public class CategoriaService extends GenericoService<Categoria, Short>{

	private final ICategoriaRepository repositorio;

	@Override
	protected IGenericoRepository<Categoria, Short> getRepo() {
		return null;
	}
}
