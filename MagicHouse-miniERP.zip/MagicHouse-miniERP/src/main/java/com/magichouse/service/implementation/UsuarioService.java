package com.magichouse.service.implementation;

import org.springframework.stereotype.Service;

import com.magichouse.model.Usuario;
import com.magichouse.repository.IUsuarioRepository;
import com.magichouse.repository.IGenericoRepository;
import com.magichouse.service.interfaces.IUsuarioService;

import lombok.RequiredArgsConstructor;

@Service
@RequiredArgsConstructor
public class UsuarioService extends GenericoService<Usuario, Short> implements IUsuarioService {

	private final IUsuarioRepository repositorio;

	@Override
	protected IGenericoRepository<Usuario, Short> getRepo() {
		return repositorio;
	}
}