package com.magichouse.service.implementation;

import org.springframework.stereotype.Service;

import com.magichouse.model.TipoMovimiento;
import com.magichouse.repository.ITipoMovimientoRepository;
import com.magichouse.repository.IGenericoRepository;
import com.magichouse.service.interfaces.ITipoMovimientoService;

import lombok.RequiredArgsConstructor;

@Service
@RequiredArgsConstructor
public class TipoMovimientoService extends GenericoService<TipoMovimiento, Short> implements ITipoMovimientoService {

	private final ITipoMovimientoRepository repositorio;

	@Override
	protected IGenericoRepository<TipoMovimiento, Short> getRepo() {
		return repositorio;
	}
}