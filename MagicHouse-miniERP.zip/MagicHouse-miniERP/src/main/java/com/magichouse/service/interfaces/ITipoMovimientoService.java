package com.magichouse.service.interfaces;

import com.magichouse.model.TipoMovimiento;

public interface ITipoMovimientoService extends IGenericoService<TipoMovimiento, Short> {
	
}