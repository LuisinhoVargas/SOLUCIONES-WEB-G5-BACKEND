package com.magichouse.service.interfaces;

import com.magichouse.model.EstadoDisfraz;

public interface IEstadoDisfrazService  extends IGenericoService<EstadoDisfraz, Short>{

}
