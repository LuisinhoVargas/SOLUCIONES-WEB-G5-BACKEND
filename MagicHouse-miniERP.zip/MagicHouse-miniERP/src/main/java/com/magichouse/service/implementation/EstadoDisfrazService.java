package com.magichouse.service.implementation;

import org.springframework.stereotype.Service;

import com.magichouse.model.EstadoDisfraz;
import com.magichouse.repository.IEstadoDisfrazRepository;
import com.magichouse.repository.IGenericoRepository;
import com.magichouse.service.interfaces.IEstadoDisfrazService;

import lombok.RequiredArgsConstructor;

@Service
@RequiredArgsConstructor
public class EstadoDisfrazService extends GenericoService<EstadoDisfraz, Short> implements IEstadoDisfrazService {

	private final IEstadoDisfrazRepository repositorio;

	@Override
	protected IGenericoRepository<EstadoDisfraz, Short> getRepo() {
		return repositorio;
	}
}