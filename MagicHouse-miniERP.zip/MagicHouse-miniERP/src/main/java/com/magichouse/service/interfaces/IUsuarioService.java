package com.magichouse.service.interfaces;

import com.magichouse.model.Usuario;

public interface IUsuarioService extends IGenericoService<Usuario, Short>{

}
