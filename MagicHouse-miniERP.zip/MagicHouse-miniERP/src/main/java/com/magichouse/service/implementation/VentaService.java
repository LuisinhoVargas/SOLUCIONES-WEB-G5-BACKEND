package com.magichouse.service.implementation;

import org.springframework.stereotype.Service;

import com.magichouse.model.Venta;
import com.magichouse.repository.IVentaRepository;
import com.magichouse.repository.IGenericoRepository;
import com.magichouse.service.interfaces.IVentaService;

import lombok.RequiredArgsConstructor;

@Service
@RequiredArgsConstructor
public class VentaService extends GenericoService<Venta, Integer> implements IVentaService {

	private final IVentaRepository repositorio;

	@Override
	protected IGenericoRepository<Venta, Integer> getRepo() {
		return repositorio;
	}
}