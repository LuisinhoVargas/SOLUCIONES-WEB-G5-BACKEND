package com.magichouse.service.implementation;

import org.springframework.stereotype.Service;

import com.magichouse.model.BoletaVenta;
import com.magichouse.repository.IBoletaVentaRepository;
import com.magichouse.repository.IGenericoRepository;
import com.magichouse.service.interfaces.IBoletaVentaService;

import lombok.RequiredArgsConstructor;

@Service
@RequiredArgsConstructor
public class BoletaVentaService extends GenericoService<BoletaVenta, Long> implements IBoletaVentaService {

	private final IBoletaVentaRepository repositorio;

	@Override
	protected IGenericoRepository<BoletaVenta, Long> getRepo() {
		return repositorio;
	}
}