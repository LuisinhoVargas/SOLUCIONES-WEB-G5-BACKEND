package com.magichouse.dto;

public class EstadoDisfrazDTO {
    private Short idEstadoDisfraz;
    private String nombreEstadoDisfraz;
    private String descripcion;
    private Boolean estaActivo;
}