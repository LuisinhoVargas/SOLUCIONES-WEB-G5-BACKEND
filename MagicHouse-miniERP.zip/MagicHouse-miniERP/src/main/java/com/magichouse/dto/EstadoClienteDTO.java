package com.magichouse.dto;

public class EstadoClienteDTO {
    private Short idEstadoCliente;
    private String nombreEstadoCliente;
    private String descripcion;
    private Boolean estaActivo;
}