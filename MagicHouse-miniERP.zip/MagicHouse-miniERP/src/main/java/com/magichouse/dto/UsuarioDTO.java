package com.magichouse.dto;

import java.time.LocalDateTime;

public class UsuarioDTO {
	
private Short idUsuario;
	
	private String nombreUsuario;
	private String correoElectronico;
	private String contraseniaHash;
	private LocalDateTime fechaRegistro;
	private LocalDateTime fechaModificacion;
	private Boolean estaActivo;
}