package com.magichouse.dto;

import java.math.BigDecimal;
import java.time.LocalDateTime;

public class BoletaVentaDTO {
    private Long idBoletaVenta;
    private Integer idVenta;
    private String nombresCliente;
    private String apellidosCliente;
    private String nombreMetodoPago;
    private String numBoleta;
    private BigDecimal total;
    private LocalDateTime fechaEmision;
    private Boolean estaActiva;
}