package com.magichouse.dto;

import java.time.LocalDateTime;

public class ReservaDisfrazDTO {
    private Long idReserva;
    private Integer idCliente;
    private Short idUsuario;
    private LocalDateTime fechaReserva;
    private Short idEstadoReserva;
}