package com.magichouse.dto;

public class TallaDTO {
    private Short idTalla;
    private String nombreTalla;
    private String descripcion;
    private Boolean estaActivo;
}