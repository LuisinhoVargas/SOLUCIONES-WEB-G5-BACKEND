package com.magichouse.dto;

import java.time.LocalDateTime;

public class ModeloDisfrazDTO {
    private Integer idModeloDisfraz;
    private String nombreModelo;
    private String descripcion;
    private Short idCategoria;
    private LocalDateTime fechaRegistro;
}