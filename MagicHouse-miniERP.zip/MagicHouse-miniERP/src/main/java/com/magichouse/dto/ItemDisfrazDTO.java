package com.magichouse.dto;

import java.time.LocalDateTime;

public class ItemDisfrazDTO {
    private Integer idItemDisfraz;
    private String codigoSKU;
    private Integer idModeloDisfraz;
    private Short idTalla;
    private Short idMaterial;
    private Short idEstadoDisfraz;
    private LocalDateTime fechaRegistro;
}