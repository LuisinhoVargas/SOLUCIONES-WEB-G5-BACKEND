package com.magichouse.dto;

public class EstadoReservaDTO {
    private Short idEstadoReserva;
    private String nombreEstadoReserva;
    private Boolean estaActivo;
}