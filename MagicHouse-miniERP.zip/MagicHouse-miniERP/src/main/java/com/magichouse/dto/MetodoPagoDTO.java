package com.magichouse.dto;

public class MetodoPagoDTO {
    private Short idMetodoPago;
    private String nombreMetodoPago;
    private Boolean estaActivo;
}