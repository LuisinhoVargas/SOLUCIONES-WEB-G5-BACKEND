package com.magichouse.dto;

import java.time.LocalDateTime;

public class ClienteDTO {
    private Integer idCliente;
    private String nombresCliente;
    private String apellidosCliente;
    private String dni;
    private String numCelular;
    private Boolean dniDevuelto;
    private LocalDateTime fechaRegistro;
    private LocalDateTime fechaModificacion;
    private String direccion;
    private Short idEstadoCliente;
}