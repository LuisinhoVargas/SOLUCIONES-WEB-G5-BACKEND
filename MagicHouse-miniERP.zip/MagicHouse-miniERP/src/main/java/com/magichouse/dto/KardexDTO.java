package com.magichouse.dto;

import java.time.LocalDateTime;

public class KardexDTO {
    private Long idKardex;
    private Integer idItemDisfraz;
    private Short idUsuario;
    private Short idTipoMovimiento;
    private String idTransaccionRef;
    private LocalDateTime fechaMovimiento;
    private Boolean estaActivo;
}