package com.magichouse.dto;

public class MaterialDTO {
    private Short idMaterial;
    private String nombreMaterial;
    private String descripcion;
    private Boolean estaActivo;
}