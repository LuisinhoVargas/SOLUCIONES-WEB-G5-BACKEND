package com.magichouse.dto;

import java.math.BigDecimal;
import java.time.LocalDateTime;

public class VentaDTO {
    private Integer idVenta;
    private Integer idCliente;
    private Short idUsuario;
    private Short idMetodoPago;
    private BigDecimal total;
    private LocalDateTime fechaVenta;
    private Boolean estaActiva;
}