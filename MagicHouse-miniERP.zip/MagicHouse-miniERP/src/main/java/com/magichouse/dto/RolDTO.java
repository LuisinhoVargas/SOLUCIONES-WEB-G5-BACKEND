package com.magichouse.dto;

public class RolDTO {
    private Short idRol;
    private Short idRolPadre;
    private String nombreRol;
    private String descripcion;
}