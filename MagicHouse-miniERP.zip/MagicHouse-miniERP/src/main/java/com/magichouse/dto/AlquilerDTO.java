package com.magichouse.dto;

import java.math.BigDecimal;
import java.time.LocalDate;

public class AlquilerDTO {
    private Long idAlquiler;
    private Integer idCliente;
    private Short idUsuario;
    private Short idMetodoPago;
    private LocalDate fechaAlquiler;
    private LocalDate fechaPactada;
    private LocalDate fechaEntrega;
    private BigDecimal total;
    private Boolean estaActivo;
}