package com.magichouse.dto;

public class CategoriaDTO {
    private Short idCategoria;
    private String nombreCategoria;
    private String descripcion;
    private Boolean estaActivo;
}