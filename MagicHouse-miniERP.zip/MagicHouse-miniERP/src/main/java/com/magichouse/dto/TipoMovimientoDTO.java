package com.magichouse.dto;

public class TipoMovimientoDTO {
    private Short idTipoMovimiento;
    private String nombreMovimiento;
    private String descripcion;
    private Boolean estaActivo;
}