package com.magichouse;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class MagicHouseMiniErpApplication {

	public static void main(String[] args) {
		SpringApplication.run(MagicHouseMiniErpApplication.class, args);
	}

}
