package com.magichouse.repository;

import com.magichouse.model.TipoMovimiento;

public interface ITipoMovimientoRepository extends IGenericoRepository<TipoMovimiento, Short> {

}