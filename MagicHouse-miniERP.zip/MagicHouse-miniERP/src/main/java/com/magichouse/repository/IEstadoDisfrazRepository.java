package com.magichouse.repository;

import com.magichouse.model.EstadoDisfraz;

public interface IEstadoDisfrazRepository extends IGenericoRepository<EstadoDisfraz, Short> {

}