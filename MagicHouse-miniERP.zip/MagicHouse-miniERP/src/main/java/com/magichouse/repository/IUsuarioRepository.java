package com.magichouse.repository;

import com.magichouse.model.Usuario;

public interface IUsuarioRepository extends IGenericoRepository<Usuario, Short> {
	
}
