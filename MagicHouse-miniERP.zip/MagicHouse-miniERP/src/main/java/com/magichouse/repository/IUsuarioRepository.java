package com.magichouse.repository;

import com.magichouse.model.Categoria;

public interface IUsuarioRepository extends IGenericoRepository<Categoria, Integer>{

}
