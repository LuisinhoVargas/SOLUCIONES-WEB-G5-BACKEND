package com.magichouse.repository;

import com.magichouse.model.EstadoReserva;

public interface IEstadoReservaRepository extends IGenericoRepository<EstadoReserva, Short> {

}