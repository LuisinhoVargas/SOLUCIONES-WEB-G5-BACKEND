package com.magichouse.repository;

import org.springframework.data.jpa.repository.JpaRepository;

public interface IGenericoRepository<T, Id> extends JpaRepository<T, Id>{

}
