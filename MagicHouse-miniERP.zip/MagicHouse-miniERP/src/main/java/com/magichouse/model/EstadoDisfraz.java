package com.magichouse.model;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
@Entity
@EqualsAndHashCode(onlyExplicitlyIncluded = true)
public class EstadoDisfraz {
	
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@EqualsAndHashCode.Include
	private Short idEstadoDisfraz;
	
	@Column(nullable = false, unique = true, length = 150)
	private String nombreEstadoDisfraz;
	
	@Column(nullable = true, length = 255)
	private String descripcion;
	
	@Column(nullable = false)
	private Boolean estaActivo;
}