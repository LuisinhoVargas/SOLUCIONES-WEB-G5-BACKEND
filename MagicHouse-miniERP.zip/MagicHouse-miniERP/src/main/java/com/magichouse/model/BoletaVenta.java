package com.magichouse.model;

import java.math.BigDecimal;
import java.time.LocalDateTime;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
@Entity
@EqualsAndHashCode(onlyExplicitlyIncluded = true)
public class BoletaVenta {
	
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@EqualsAndHashCode.Include
	private Long idBoletaVenta;
	
	@Column(nullable = false)
	private Long idVenta;
	
	@Column(nullable = false, length = 150)
	private String nombresCliente;
	
	@Column(nullable = false, length = 150)
	private String apellidosCliente;
	
	@Column(nullable = false, length = 150)
	private String nombreMetodoPago;
	
	@Column(nullable = false, unique = true, length = 20)
	private String numBoleta;
	
	@Column(nullable = false, precision = 10, scale = 2)
	private BigDecimal subTotal;
	
	@Column(nullable = false, precision = 10, scale = 2)
	private BigDecimal igv;
	
	@Column(nullable = false, precision = 10, scale = 2)
	private BigDecimal total;
	
	@Column(nullable = false, updatable = false)
	private LocalDateTime fechaEmision;
	
	@Column(nullable = false)
	private Boolean estaActiva;
}