package com.magichouse.model;

import jakarta.persistence.*;
import lombok.*;
import java.time.LocalDateTime;
import java.util.List;

@Data
@NoArgsConstructor
@AllArgsConstructor
@Entity
@EqualsAndHashCode(onlyExplicitlyIncluded = true)
public class ItemDisfraz {
    
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @EqualsAndHashCode.Include
    private Integer idItemDisfraz;
    
    @Column(nullable = false, unique = true, length = 50)
    private String codigoSKU;
    
    @ManyToOne
    @JoinColumn(name = "id_modelo_disfraz", nullable = false, foreignKey = @ForeignKey(name = "FK_ITEMDISFRAZ_MODELODISFRAZ"))
    private ModeloDisfraz modeloDisfraz;
    
    @ManyToOne
    @JoinColumn(name = "id_talla", nullable = false, foreignKey = @ForeignKey(name = "FK_ITEMDISFRAZ_TALLA"))
    private Talla talla;
    
    @ManyToOne
    @JoinColumn(name = "id_material", nullable = false, foreignKey = @ForeignKey(name = "FK_ITEMDISFRAZ_MATERIAL"))
    private Material material;
    
    @ManyToOne
    @JoinColumn(name = "id_estado_disfraz", nullable = false, foreignKey = @ForeignKey(name = "FK_ITEMDISFRAZ_ESTADODISFRAZ"))
    private EstadoDisfraz estadoDisfraz;
    
    @Column(nullable = false)
    private LocalDateTime fechaRegistro;
    
    @OneToMany(mappedBy = "itemDisfraz", cascade = CascadeType.ALL, orphanRemoval = true)
    private List<DetalleVenta> detallesVenta;
    
    @OneToMany(mappedBy = "itemDisfraz", cascade = CascadeType.ALL, orphanRemoval = true)
    private List<DetalleAlquiler> detallesAlquiler;
    
    @OneToMany(mappedBy = "itemDisfraz", cascade = CascadeType.ALL, orphanRemoval = true)
    private List<DetalleReserva> detallesReserva;
    
    @OneToMany(mappedBy = "itemDisfraz", cascade = CascadeType.ALL, orphanRemoval = true)
    private List<Kardex> kardexList;
}