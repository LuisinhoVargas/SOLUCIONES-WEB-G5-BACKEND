package com.magichouse.model;

import java.time.LocalDateTime;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
@Entity
@EqualsAndHashCode(onlyExplicitlyIncluded = true)
public class ItemDisfraz {
	
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@EqualsAndHashCode.Include
	private Integer idItemDisfraz;
	
	@Column(nullable = false, unique = true, length = 150)
	private String codigoSKU;
	
	@Column(nullable = false)
	private Integer idModeloDisfraz;
	
	@Column(nullable = false)
	private Short idTalla;
	
	@Column(nullable = false)
	private Short idMaterial;
	
	@Column(nullable = false)
	private Short idEstadoDisfraz;
	
	@Column(nullable = false, updatable = false)
	private LocalDateTime fechaRegistro;
}