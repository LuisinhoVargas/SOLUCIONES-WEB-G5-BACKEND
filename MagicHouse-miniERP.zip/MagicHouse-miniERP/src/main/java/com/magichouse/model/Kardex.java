package com.magichouse.model;

import java.time.LocalDateTime;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
@Entity
@EqualsAndHashCode(onlyExplicitlyIncluded = true)
public class Kardex {
	
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@EqualsAndHashCode.Include
	private Long idKardex;
	
	@Column(nullable = false)
	private Integer idItemDisfraz;
	
	@Column(nullable = false)
	private Short idTipoMovimiento;
	
	@Column(nullable = false, length = 150)
	private String idTransaccionRef;
	
	@Column(nullable = false, updatable = false)
	private LocalDateTime fechaMovimiento;
	
	@Column(nullable = false)
	private Boolean estaActivo;
}