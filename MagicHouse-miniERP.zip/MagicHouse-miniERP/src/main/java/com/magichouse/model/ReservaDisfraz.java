package com.magichouse.model;

import java.time.LocalDateTime;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
@Entity
@EqualsAndHashCode(onlyExplicitlyIncluded = true)
public class ReservaDisfraz {
	
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@EqualsAndHashCode.Include
	private Long idReserva;
	
	@Column(nullable = false)
	private Integer idCliente;
	
	@Column(nullable = false)
	private Short idUsuario;
	
	@Column(nullable = false, updatable = false)
	private LocalDateTime fechaReserva;
	
	@Column(nullable = false)
	private Short idEstadoReserva;
}