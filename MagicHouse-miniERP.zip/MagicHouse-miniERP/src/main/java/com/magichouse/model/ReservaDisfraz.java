package com.magichouse.model;

import jakarta.persistence.*;
import lombok.*;
import java.time.LocalDateTime;
import java.util.List;

@Data
@NoArgsConstructor
@AllArgsConstructor
@Entity
@EqualsAndHashCode(onlyExplicitlyIncluded = true)
public class ReservaDisfraz {
    
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @EqualsAndHashCode.Include
    private Long idReserva;
    
    @ManyToOne
    @JoinColumn(name = "id_cliente", nullable = false, foreignKey = @ForeignKey(name = "FK_RESERVADISFRAZ_CLIENTE"))
    private Cliente cliente;
    
    @ManyToOne
    @JoinColumn(name = "id_usuario", nullable = false, foreignKey = @ForeignKey(name = "FK_RESERVADISFRAZ_USUARIO"))
    private Usuario usuario;
    
    @ManyToOne
    @JoinColumn(name = "id_estado_reserva", nullable = false, foreignKey = @ForeignKey(name = "FK_RESERVADISFRAZ_ESTADORESERVA"))
    private EstadoReserva estadoReserva;
    
    @Column(nullable = false)
    private LocalDateTime fechaReserva;
    
    @OneToMany(mappedBy = "reservaDisfraz", cascade = CascadeType.ALL, orphanRemoval = true)
    private List<DetalleReserva> detallesReserva;
}