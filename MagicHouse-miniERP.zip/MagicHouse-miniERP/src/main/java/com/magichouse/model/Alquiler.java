package com.magichouse.model;

import jakarta.persistence.*;
import lombok.*;
import java.math.BigDecimal;
import java.time.LocalDate;
import java.util.List;

@Data
@NoArgsConstructor
@AllArgsConstructor
@Entity
@EqualsAndHashCode(onlyExplicitlyIncluded = true)
public class Alquiler {
    
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @EqualsAndHashCode.Include
    private Long idAlquiler;
    
    @ManyToOne
    @JoinColumn(name = "id_cliente", nullable = false, foreignKey = @ForeignKey(name = "FK_ALQUILER_CLIENTE"))
    private Cliente cliente;
    
    @ManyToOne
    @JoinColumn(name = "id_usuario", nullable = false, foreignKey = @ForeignKey(name = "FK_ALQUILER_USUARIO"))
    private Usuario usuario;
    
    @ManyToOne
    @JoinColumn(name = "id_metodo_pago", nullable = false, foreignKey = @ForeignKey(name = "FK_ALQUILER_METODOPAGO"))
    private MetodoPago metodoPago;
    
    @Column(nullable = false)
    private LocalDate fechaAlquiler;
    
    @Column(nullable = false)
    private LocalDate fechaPactada;
    
    @Column(nullable = true)
    private LocalDate fechaEntrega;
    
    @Column(nullable = false, precision = 10, scale = 2)
    private BigDecimal total;
    
    @Column(nullable = false)
    private Boolean estaActivo;
    
    @OneToMany(mappedBy = "alquiler", cascade = CascadeType.ALL, orphanRemoval = true)
    private List<DetalleAlquiler> detallesAlquiler;
}