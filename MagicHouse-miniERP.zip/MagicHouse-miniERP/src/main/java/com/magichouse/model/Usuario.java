package com.magichouse.model;

import java.time.LocalDateTime;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
@Entity
@EqualsAndHashCode(onlyExplicitlyIncluded = true)
public class Usuario {
	
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@EqualsAndHashCode.Include
	private Short idUsuario;
	
	@Column(nullable = false, unique = true, length = 150)
	private String nombreUsuario;
	
	@Column(nullable = false, unique = true, length = 255)
	private String correoElectronico;
	
	@Column(nullable = false, unique = true, length = 255)
	private String contraseniaHash;
	
	@Column(nullable = false, updatable = false)
	private LocalDateTime fechaRegistro;
	
	@Column(nullable = true)
	private LocalDateTime fechaModificacion;
	
	@Column(nullable = false)
	private Boolean estaActivo;
}
