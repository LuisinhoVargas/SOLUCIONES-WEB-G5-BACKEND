package com.magichouse.model.usuario_rol;

import com.magichouse.model.Rol;
import com.magichouse.model.Usuario;

import jakarta.persistence.Embeddable;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.ManyToOne;
import lombok.AllArgsConstructor;
import jakarta.persistence.ForeignKey;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
@Embeddable
public class UsuarioRolFK {

    @ManyToOne
    @JoinColumn(name="id_usuario", foreignKey = @ForeignKey(name="FK_USUARIOROL_USUARIO"))
    private Usuario usuario;

    @ManyToOne
    @JoinColumn(name="id_rol", foreignKey = @ForeignKey(name="FK_PROVIDERTAG_TAG"))
    private Rol rol;
}