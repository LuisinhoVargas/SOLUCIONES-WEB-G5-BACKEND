package com.magichouse.model;

import java.math.BigDecimal;
import java.time.LocalDateTime;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
@Entity
@EqualsAndHashCode(onlyExplicitlyIncluded = true)
public class Venta {
	
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@EqualsAndHashCode.Include
	private Integer idVenta;
	
	@Column(nullable = false)
	private Integer idCliente;
	
	@Column(nullable = false)
	private Short idUsuario;
	
	@Column(nullable = false)
	private Short idMetodoPago;
	
	@Column(nullable = false, precision = 10, scale = 2)
	private BigDecimal total;
	
	@Column(nullable = false, updatable = false)
	private LocalDateTime fechaVenta;
	
	@Column(nullable = false)
	private Boolean estaActiva;
}