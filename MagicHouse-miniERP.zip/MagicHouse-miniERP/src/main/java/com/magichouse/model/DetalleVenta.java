package com.magichouse.model;

import jakarta.persistence.*;
import lombok.*;
import java.math.BigDecimal;

@Data
@NoArgsConstructor
@AllArgsConstructor
@Entity
@EqualsAndHashCode(onlyExplicitlyIncluded = true)
public class DetalleVenta {
    
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @EqualsAndHashCode.Include
    private Long idDetalleVenta;
    
    @ManyToOne
    @JoinColumn(name = "id_venta", nullable = false, foreignKey = @ForeignKey(name = "FK_DETALLEVENTA_VENTA"))
    private Venta venta;
    
    @ManyToOne
    @JoinColumn(name = "id_item_disfraz", nullable = false, foreignKey = @ForeignKey(name = "FK_DETALLEVENTA_ITEMDISFRAZ"))
    private ItemDisfraz itemDisfraz;
    
    @Column(nullable = false, precision = 10, scale = 2)
    private BigDecimal precioUnitarioVenta;
}