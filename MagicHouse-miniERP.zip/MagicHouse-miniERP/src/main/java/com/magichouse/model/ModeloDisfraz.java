package com.magichouse.model;

import java.time.LocalDateTime;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
@Entity
@EqualsAndHashCode(onlyExplicitlyIncluded = true)
public class ModeloDisfraz {
	
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@EqualsAndHashCode.Include
	private Integer idModeloDisfraz;
	
	@Column(nullable = false, unique = true, length = 150)
	private String nombreModelo;
	
	@Column(nullable = true, length = 255)
	private String descripcion;
	
	@Column(nullable = false)
	private Short idCategoria;
	
	@Column(nullable = false, updatable = false)
	private LocalDateTime fechaRegistro;
}