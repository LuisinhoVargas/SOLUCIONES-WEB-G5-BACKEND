package com.magichouse.model;

import jakarta.persistence.*;
import lombok.*;
import java.time.LocalDateTime;
import java.util.List;

@Data
@NoArgsConstructor
@AllArgsConstructor
@Entity
@EqualsAndHashCode(onlyExplicitlyIncluded = true)
public class ModeloDisfraz {
    
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @EqualsAndHashCode.Include
    private Integer idModeloDisfraz;
    
    @Column(nullable = false, unique = true, length = 100)
    private String nombreModelo;
    
    @Column(nullable = true, length = 255)
    private String descripcion;
    
    @ManyToOne
    @JoinColumn(name = "id_categoria", nullable = false, foreignKey = @ForeignKey(name = "FK_MODELODISFRAZ_CATEGORIA"))
    private Categoria categoria;
    
    @Column(nullable = false)
    private LocalDateTime fechaRegistro;
    
    @OneToMany(mappedBy = "modeloDisfraz", cascade = CascadeType.ALL, orphanRemoval = true)
    private List<ItemDisfraz> itemsDisfraz;
}