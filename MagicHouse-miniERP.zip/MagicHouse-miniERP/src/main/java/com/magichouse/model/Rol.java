package com.magichouse.model;

import jakarta.persistence.CascadeType;
import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.ForeignKey;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.ManyToOne;
import jakarta.persistence.OneToMany;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.NoArgsConstructor;

import java.util.List;

@Data
@NoArgsConstructor
@AllArgsConstructor
@Entity
@EqualsAndHashCode(onlyExplicitlyIncluded = true)
public class Rol {
	
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@EqualsAndHashCode.Include
	private Short idRol;
	
	@ManyToOne
	@JoinColumn(name = "id_rol_padre", nullable = true, foreignKey = @ForeignKey(name = "FK_ROL_ROLPADRE"))
	private Rol rolPadre;
	
	@Column(nullable = false, unique = true, length = 50)
	private String nombreRol;
	
	@Column(nullable = true, length = 255)
	private String descripcion;
	
	@OneToMany(mappedBy = "rolPadre", cascade = CascadeType.ALL, orphanRemoval = true)
	private List<Rol> subRoles;
}