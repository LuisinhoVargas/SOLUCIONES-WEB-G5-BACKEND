package com.magichouse.model;

import java.math.BigDecimal;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
@Entity
@EqualsAndHashCode(onlyExplicitlyIncluded = true)
public class DetalleAlquiler {
	
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@EqualsAndHashCode.Include
	private Integer idDetalleAlquiler;
	
	@Column(nullable = false)
	private Integer idItemDisfraz;
	
	@Column(nullable = false)
	private Long idAlquiler;
	
	@Column(nullable = false, precision = 10, scale = 2)
	private BigDecimal precioUnitarioAlquiler;
	
	@Column(nullable = false, precision = 10, scale = 2)
	private BigDecimal descuentoPorMayor;
	
	@Column(nullable = false, precision = 10, scale = 2)
	private BigDecimal cargoDanio;
}