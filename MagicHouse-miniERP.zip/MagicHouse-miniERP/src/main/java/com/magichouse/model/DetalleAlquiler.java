package com.magichouse.model;

import jakarta.persistence.*;
import lombok.*;
import java.math.BigDecimal;

@Data
@NoArgsConstructor
@AllArgsConstructor
@Entity
@EqualsAndHashCode(onlyExplicitlyIncluded = true)
public class DetalleAlquiler {
    
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @EqualsAndHashCode.Include
    private Integer idDetalleAlquiler;
    
    @ManyToOne
    @JoinColumn(name = "id_alquiler", nullable = false, foreignKey = @ForeignKey(name = "FK_DETALLEALQUILER_ALQUILER"))
    private Alquiler alquiler;
    
    @ManyToOne
    @JoinColumn(name = "id_item_disfraz", nullable = false, foreignKey = @ForeignKey(name = "FK_DETALLEALQUILER_ITEMDISFRAZ"))
    private ItemDisfraz itemDisfraz;
    
    @Column(nullable = false, precision = 10, scale = 2)
    private BigDecimal precioUnitarioAlquiler;
    
    @Column(nullable = false, precision = 10, scale = 2)
    private BigDecimal descuentoPorMayor;
    
    @Column(nullable = false, precision = 10, scale = 2)
    private BigDecimal cargoDanio;
}