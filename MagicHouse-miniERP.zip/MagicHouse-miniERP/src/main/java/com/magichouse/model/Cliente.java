package com.magichouse.model;

import jakarta.persistence.*;
import lombok.*;
import java.time.LocalDateTime;
import java.util.List;

@Data
@NoArgsConstructor
@AllArgsConstructor
@Entity
@EqualsAndHashCode(onlyExplicitlyIncluded = true)
public class Cliente {
    
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @EqualsAndHashCode.Include
    private Integer idCliente;
    
    @Column(nullable = false, length = 100)
    private String nombresCliente;
    
    @Column(nullable = false, length = 100)
    private String apellidosCliente;
    
    @Column(nullable = false, unique = true, length = 20)
    private String dni;
    
    @Column(nullable = true, length = 20)
    private String numCelular;
    
    @Column(nullable = true)
    private Boolean dniDevuelto;
    
    @Column(nullable = false)
    private LocalDateTime fechaRegistro;
    
    @Column(nullable = false)
    private LocalDateTime fechaModificacion;
    
    @Column(nullable = true, length = 255)
    private String direccion;
    
    @ManyToOne
    @JoinColumn(name = "id_estado_cliente", nullable = false, foreignKey = @ForeignKey(name = "FK_CLIENTE_ESTADOCLIENTE"))
    private EstadoCliente estadoCliente;
    
    @OneToMany(mappedBy = "cliente", cascade = CascadeType.ALL, orphanRemoval = true)
    private List<Venta> ventas;
    
    @OneToMany(mappedBy = "cliente", cascade = CascadeType.ALL, orphanRemoval = true)
    private List<Alquiler> alquileres;
    
    @OneToMany(mappedBy = "cliente", cascade = CascadeType.ALL, orphanRemoval = true)
    private List<ReservaDisfraz> reservas;
}