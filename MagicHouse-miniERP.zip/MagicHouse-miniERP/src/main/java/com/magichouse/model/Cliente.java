package com.magichouse.model;

import java.time.LocalDateTime;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
@Entity
@EqualsAndHashCode(onlyExplicitlyIncluded = true)
public class Cliente {
	
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@EqualsAndHashCode.Include
	private Integer idCliente;
	
	@Column(nullable = false, length = 150)
	private String nombresCliente;
	
	@Column(nullable = false, length = 150)
	private String apellidosCliente;
	
	@Column(nullable = false, unique = true, length = 20)
	private String dni;
	
	@Column(nullable = true, length = 20)
	private String numCelular;
	
	@Column(nullable = true)
	private Boolean dniDevuelto;
	
	@Column(nullable = false, updatable = false)
	private LocalDateTime fechaRegistro;
	
	@Column(nullable = true)
	private LocalDateTime fechaModificacion;
	
	@Column(nullable = true, length = 255)
	private String direccion;
	
	@Column(nullable = false)
	private Short idEstadoCliente;
}