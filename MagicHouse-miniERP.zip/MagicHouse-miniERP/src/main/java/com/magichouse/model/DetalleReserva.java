package com.magichouse.model;

import jakarta.persistence.*;
import lombok.*;
import java.time.LocalDateTime;

@Data
@NoArgsConstructor
@AllArgsConstructor
@Entity
@EqualsAndHashCode(onlyExplicitlyIncluded = true)
public class DetalleReserva {
    
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @EqualsAndHashCode.Include
    private Long idDetalleReserva;
    
    @ManyToOne
    @JoinColumn(name = "id_reserva", nullable = false, foreignKey = @ForeignKey(name = "FK_DETALLERESERVA_RESERVADISFRAZ"))
    private ReservaDisfraz reservaDisfraz;
    
    @ManyToOne
    @JoinColumn(name = "id_item_disfraz", nullable = false, foreignKey = @ForeignKey(name = "FK_DETALLERESERVA_ITEMDISFRAZ"))
    private ItemDisfraz itemDisfraz;
    
    @Column(nullable = false)
    private LocalDateTime fechaRecojo;
    
    @Column(nullable = false)
    private LocalDateTime fechaDevolucion;
}