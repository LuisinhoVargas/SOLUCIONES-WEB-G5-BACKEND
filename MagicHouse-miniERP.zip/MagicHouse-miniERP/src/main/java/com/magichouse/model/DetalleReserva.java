package com.magichouse.model;

import java.time.LocalDateTime;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
@Entity
@EqualsAndHashCode(onlyExplicitlyIncluded = true)
public class DetalleReserva {
	
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@EqualsAndHashCode.Include
	private Long idDetalleReserva;
	
	@Column(nullable = false)
	private Long idReserva;
	
	@Column(nullable = false)
	private Integer idItemDisfraz;
	
	@Column(nullable = false)
	private LocalDateTime fechaRecojo;
	
	@Column(nullable = false)
	private LocalDateTime fechaDevolucion;
}